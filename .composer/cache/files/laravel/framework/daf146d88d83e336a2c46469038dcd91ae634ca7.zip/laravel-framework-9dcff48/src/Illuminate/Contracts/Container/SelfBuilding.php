<?php

namespace Illuminate\Contracts\Container;

/**
 * @method static newInstance(): static
 */
interface SelfBuilding
{
}
