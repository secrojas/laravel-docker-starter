<?php

namespace Illuminate\Cache\Events;

class ForgettingKey extends CacheEvent
{
    //
}
